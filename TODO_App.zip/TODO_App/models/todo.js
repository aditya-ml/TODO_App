const mongoose = require('mongoose'); // import database

// create schema
const todoSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    item_category: {
        type: String,
        required: true
    },
    date: {
        type: String,
        required: true
    }
});

const Todo = mongoose.model('Todo', todoSchema); // set model

module.exports = Todo; // tell app to use it
// import model
const Todo = require('../models/todo');

// call-back function to create task item
module.exports.createItem = function(req, res){
    console.log(req);
    console.log(req.body);

   Todo.create({
       name: req.body.name,
       item_category: req.body.item_category,
       date: req.body.date
      
   }, function(err, newItem){
        if(err){
            
            console.log('error in creating item');
            console.log(req.body);
            return;
        }
        console.log('********', newItem);
        return res.redirect('back');
   }); 
}

// callback function to delete task item
module.exports.deleteItem = function(req, res){
    console.log(req.query);
    let id = req.query.id;
    Todo.findByIdAndDelete(id, function(err){
        if(err){
            console.log('error in deleting item from database');
            return;
        }
        return res.redirect('back');
    })
}
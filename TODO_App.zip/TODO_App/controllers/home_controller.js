// import model
const Todo = require('../models/todo');

// call-back function to display home page screen of app
module.exports.home = function(req, res){
    
    Todo.find({}, function(err, todo_items){
        if(err){
            console.log('error in fetching items');
            return;
        }
        
        return res.render('home',{
            todo_items: todo_items
        });
    });
}


// require the library
const mongoose = require("mongoose");

// connection to database
mongoose.connect('mongodb://localhost/todo_list_db');

// acquire the conncection (to check if it is successful)
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'error in connecting to db'));

db.once('open', function(){
    console.log('Successfully connected to the database');
})

// portable
module.exports = db;
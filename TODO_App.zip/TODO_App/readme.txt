My TODO App by Aditya Singhal

To run:
1. Unzip file in visual studio 
2. Use command: npm start
3. Open localhost:8000 in Google chrome
4. Please check database compatibilty in your machine 

Refer to app_screenshot.jpg file for a screenshot of my application.

For questions/clarifications ping me on 9873862708 or aditya98singhal@gmail.com
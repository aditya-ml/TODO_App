// import required libraries
const express = require('express');
const path = require('path');
const router = require('./routes');

const port = 8000;

// configure mongoose database
const db = require('./config/mongoose');

const app=express();

// body parser
app.use(express.urlencoded());

// access static files
app.use(express.static('assets'));

// use express router
app.use('/', require('./routes'));

// set ejs engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname,'views'));

app.listen(port,function(err){
    if(err){
        console.log(err);
    }
    console.log('Server is running on port: ',port);
});
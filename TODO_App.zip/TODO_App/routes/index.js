//Entry point to all routes

const express = require("express");

const router = express.Router();

//access home_controller here
const homeController = require('../controllers/home_controller');
router.get('/', homeController.home) // '/' is the url where I want to put it

// access tasks_controller here
const tasksController = require('../controllers/tasks_controller');

router.post('/create-item',tasksController.createItem);

router.get('/delete-item/', tasksController.deleteItem);

//for any further routes, access from here
//router.use('/routerName', require('./routerFile'));

module.exports = router; //tell app to use it
